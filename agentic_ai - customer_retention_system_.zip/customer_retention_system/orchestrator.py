from agents.churn_agent import Churn_Agent
from agents.behaviour_agent import Behavior_agent
from agents.sentiment_agent import Sentiment_analysis
from agents.rootcause_agent import Root_cause_agent
from agents.strategy_agent import RetensionStrategyAgent
from agents.intervention_agent import InterventionAgent 
from agents.relationship_agent import RelationshipAgent 
from agents.outcome_agent import OutcomeAgent 

class RetentionOrchestrator:

    def __init__(self):
        self.churn = Churn_Agent()
        self.behaviour = Behavior_agent()
        self.sentiment = Sentiment_analysis()
        self.rootcause = Root_cause_agent()
        self.strategy = RetensionStrategyAgent()
        self.intervention = InterventionAgent()
        self.relation = RelationshipAgent()
        self.outcome = OutcomeAgent()

    def run_full_retention_flow(self, customer_id, text):

        churn = self.churn.predict_churn(customer_id)
        behaviour = self.behaviour.analyze_behavior(customer_id)
        sentiment = self.sentiment.analyze_sentiment(customer_id)
        rootcause = self.rootcause.analyze_root_cause(customer_id)
        strategy = self.strategy.create_strategy(customer_id)
        intervention = self.intervention.execute_intervention(customer_id)
        relationship = self.relation.manange_relationship(customer_id)
        outcome = self.outcome.track_outcome(customer_id)

        return {
            "churn" : churn,
            "behaviour" : behaviour,
            "sentiment" : sentiment,
            "rootcause" : rootcause,
            "strategy" : strategy,
            "intervention" : intervention,
            "relationship" : relationship,
            "outcome" : outcome
        }
