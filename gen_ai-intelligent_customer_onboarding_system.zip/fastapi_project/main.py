from fastapi import FastAPI, UploadFile, File, WebSocket, WebSocketDisconnect 
from pydantic import BaseModel 
import uuid 
from typing import List, Optional 
from datetime import datetime 

app = FastAPI(title = "Intelligent Customer Onboading Assistant")


# data models

class CustomerInfo(BaseModel):
  first_name : str
  last_name : str 
  email : str 
  phone : str 
  ssn : Optional[str] = None 
  address : Optional[str] = None 
  employment_info : Optional[str] = None
  financial_goals : Optional[str] = None
  risk_tolerance : Optional[str] = None
  linked_accounts : Optional[List[str]] = None 

class AccountSelection(BaseModel):
  account_type : str
  features : List[str]
  beneficiary_info : Optional[List[str]] = None 
  card_customization : Optional[str] = None 


class Consent(BaseModel):
  terms : bool # y/n
  marketing : bool
  data_usage : bool 

class Transaction(BaseModel):
  amount : float

class SupportTicket(BaseModel):
  subject : str 
  message : str
  
# in-memory databases 

sessions = {}
customers = {}
accounts = {}
tickets = {}
notifications = {}

# customers welcome by api 
@app.post("/start_session/")
async def start_session():
  session_id = str(uuid.uuid4())
  sessions[session_id] = {"status" : "started"}
  return {"session_id" : session_id, "message" : "welcome your onboarding session has started."}

@app.post("/upload_id/")
async def upload_id(session_id : str, file : UploadFile = File(...)):
  if session_id not in sessions:
    return {"error" : "Invalid sessions"}
  sessions[session_id]["id_verified"] = True 
  return {"message" : "ID uploaded successfully!"}


@app.post("/collect_consent/")
async def collect_consent(session_id : str, consent : Consent):
  if session_id not in sessions:
    return {"error" : "Invalid sessions"}
  sessions[session_id]["consent"] = consent.dict()
  return {"message" : "Consent collected successfully!"}

@app.post("/verify_biometric/")
async def verify_biometric(session_id: str, selfie_file : UploadFile = File(...)):
  if session_id not in sessions:
    return {"error" : "Invalid sessions"}  
  sessions[session_id]["biometric_verified"] = True 
  if session_id not in sessions:
    return {"error" : "Invalid sessions"}
  return {"verified" : True}


@app.post("/collect_info/")
async def collect_info(session_id : str, customer_info : CustomerInfo):
  if session_id not in sessions:
    return {"error" : "Invalid customer"}

  customer_id = str(uuid.uuid4())
  customers[customer_id] = customer_info.dict()
  sessions[session_id]["customer_id"] = customer_id 
  notifications[customer_id] = []
  if session_id not in sessions:
    return {"error" : "Invalid sessions"}
  return {"customer_id" : customer_id}

@app.post("/assess_financial_profile/{customer_id}")
async def assess_financial_profile(customer_id : str):
  if customer_id not in customers:
    return {"error" : "Invalid customer"}
  customers[customer_id]["risk_score"] = "low"
  customers[customer_id]["profile_completed"] = True 
  return {"status" : "assessed"}

@app.post("/recommend_products/{customer_id}")
async def recommend_products(customer_id : str):
  if customer_id not in customers:
    return {"error" : "Invalid customer"}
  return {
      "products" : [
          {"name" : "premium_checking", "score" : 0.92},
          {"name" : "savings plus", "score" : 0.88 },
          {"name" : "gold credit card" , "score" : 0.85}
           ]
    }

@app.post("/open_account/{customer_id}")
async def open_account(customer_id : str, account : AccountSelection):
  if customer_id not in customers:
    return {"error" : "Invalid customer"}
  acc_no = str(uuid.uuid4())[:12]
  accounts[acc_no] = {
      "customer_id" : customer_id,
      "type" : account.account_type,
      "features" : account.features,
      "balance" : 0.0,
      "created_at" : datetime.utcnow(),
      "active" : False

  }
  return {"account_number" : acc_no}


@app.post("/activate_account/{account_number}")
async def activate_account(account_number : str, deposit : float = 0):
  if account_number not in accounts:
    return {"error" : "Invalid account"}
  accounts[account_number]["active"] = True 
  accounts[account_number]["balance"] += deposit 
  return accounts[account_number]

@app.post("/deposit/{account_number}")
async def deposit_money(account_number : str, tx: Transaction):
  if account_number not in accounts:
    return {"error" : "Invalid account"}
  accounts[account_number]["balance"] += tx.amount 
  return {"balance" : accounts[account_number]["balance"]}

@app.post("/withdraw/{account_number}")
async def withdraw_money(account_number : str, tx: Transaction):
  if account_number not in accounts:
    return {"error" : "Invalid account"}
  if accounts[account_number]["balance"] < tx.amount:
    return {"error" : "insufficient funds"}
  accounts[account_number]["balance"] -= tx.amount 
  return {"balance" : accounts[account_number]["balance"]}

@app.post("/compliance_check/{customer_id}")
async def compliance_check(customer_id : str):
  if customer_id not in customers:
    return {"error" : "Invalid customer"}
  customers[customer_id]["compliance"] = "passed"
  return {"status" : "passed"}

@app.get("/onboarding_content/{customer_id}")
async def onboarding_content(customer_id :str):
  if customer_id not in customers:
    return {"error" : "Invalid customer"}
  return {
      "videos" : ["Intro", "security", "Investing"],
      "articles" : ["saving_tips", "credit_usage"],
      "offers" : ["5% cashback"]
  }
  
@app.post("/support_ticket/{customer_id}")
async def support_ticket(customer_id : str, ticket : SupportTicket):
  ticket_id = str(uuid.uuid4())
  tickets[ticket_id] = {
      "customer_id" : customer_id,
      "subject" : ticket.subject,
      "message" : ticket.message,
      'status' : "open"
  }
  return {"ticket_id": ticket_id}

@app.get("/notifications/{customer_id}")
async def get_notifications(customer_id : str):
  return notifications.get(customer_id, [])

@app.websocket("/chat/{session_id}")
async def websocket_chat(websocket : WebSocket, session_id : str):
  await websocket.accept()
  try:
    while True:
      text = await websocket.receive_text()
      await websocket.send_text(f"AI = {text}")
  except WebSocketDisconnect:
      pass
                              








