from fastapi import FastAPI
from pydantic import BaseModel
from database import customers_db
from orchestrator import RetentionOrchestrator

api = FastAPI(title = "multi agent customer retention system",
              version = "1.0")

orchastrator = RetentionOrchestrator()

# models 

class Customer(BaseModel):
    customer_id : str
    name : str 
    account_type : str 
    balance : float 

class SentimentInput(BaseModel):
    customer_id : str 
    text : str 


# customer Apis 

@api.post("/customers/onboard")
def onboard_customer(customer : Customer):

    customers_db[customer.customer_id] = customer.dict()

    return {
        "message" : "customer onboarded successfully!",
        "customer" : customer
    }


@api.get("/customers/{customer_id}")
def get_customer(customer_id: str):

    return customers_db.get(customer_id, "customer_not_found")

#churn prediction api 

@api.post("/churn/predict/{customer_id}")
def predict_churn(customer_id : str):

    return orchastrator.churn.predict_churn(customer_id)


# behavior analysis api 

@api.post("/behaviour/analyze/{customer_id}")
def behavior_analysis(customer_id : str):

    return orchastrator.behaviour.analyze_behavior(customer_id)


# sentiment analysis api 
@api.post("/sentiment/analyze")
def sentiment_analysis(data: SentimentInput):

    return orchastrator.sentiment.analyze_sentiment(
        data.customer_id,
        data.text
    )

@api.get("/retention-test")
def test():
    return {"message": "Retention working"}


# full retention flow api 
@api.post("/retention/run-full/{customer_id}")
def run_full_flow(customer_id: str, text:str):

    return  orchastrator.run_full_retention_flow(customer_id, text)






