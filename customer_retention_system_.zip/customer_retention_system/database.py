customers_db = {}
churn_scores_db = {}
behaviour_db = {}
sentiment_db = {}
rootcause_db = {}
strategy_db = {}
intervention_db = {}
outcome_db = {}