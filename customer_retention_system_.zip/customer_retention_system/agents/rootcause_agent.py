from database import rootcause_db

class Root_cause_agent:
    def analyze_root_cause(self, customer_id):

        causes = [
            "High service charges",
            "poor mobile app experience",
            "better competitor offers"  
            ]
        
        report = {
            "customer_id" : customer_id,
            "root_causes" : causes
            }
        
        rootcause_db[customer_id] = report 
        return report 
