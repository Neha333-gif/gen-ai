import random 
from database import churn_scores_db 

class Churn_Agent:

    def predict_churn(self, customer_id):
        score = round(random.uniform(0.7), 2)

        risk = "high" if score > 0.7 else "medium" if score > 0.4 else "low"

        result = {
            "customer_id" : customer_id,
            "churn_score" : score, 
            "risk_level" : risk
        }

        churn_scores_db[customer_id] = result 
        return result