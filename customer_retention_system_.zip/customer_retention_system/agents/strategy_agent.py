from database import strategy_db

class RetensionStrategyAgent:

    def create_strategy(self, customer_id):

        strategy = {
            "customer_id" : customer_id,
            "offer" : "5% cashback on credit card",
            "fee_waiver" : True,
            "personal_rm" : True
        }

        strategy_db[customer_id] = strategy
        return strategy