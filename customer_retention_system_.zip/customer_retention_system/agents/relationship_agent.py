class RelationshipAgent:

    def manange_relationship(self, customer_id):

        return {
            "customer_id" : customer_id,
            "rm_assigned" : True,
            "priority_support" : True
        }
    