from database import intervention_db

class InterventionAgent:

    def execute_intervention(self,customer_id):

        result = {
            "customer_id" : customer_id,
            "status" : "offer_sent", 
            "channel" :"email + sms"
        }

        intervention_db[customer_id] = result