from textblob import TextBlob 
from database import sentiment_db

class Sentiment_analysis:

    def analyze_sentiment(self, customer_id, text):

        polarity = TextBlob(text).sentiment.polarity 

        sentiment = "negative" if polarity < 0 else "positive"

        result = {
            "customer_id" : customer_id,
            "sentiment" : sentiment,
            "polarity" : polarity
        }

        sentiment_db[customer_id] = result 
        return result 
