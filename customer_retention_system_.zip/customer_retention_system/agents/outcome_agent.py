from database import outcome_db

class OutcomeAgent:

    def track_outcome(self, customer_id):
        
        outcome = {
            "customer_id" : customer_id, 
            "retained" : True,
            "roi" : "18%",
            "satisfaction_score" : 8.5
        }

        outcome_db[customer_id] = outcome 
        return outcome 