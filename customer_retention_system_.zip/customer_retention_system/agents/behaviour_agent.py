from database import behaviour_db

class Behavior_agent:

    def analyze_behavior(self, customer_id):

        report = {
            "customer_id" : customer_id, 
            "transaction_drop" : True,
            "low_product_usage" : True,
            "engagement_score" : 42
        }

        behaviour_db[customer_id] = report 
        return report